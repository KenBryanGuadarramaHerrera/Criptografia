# Importar db y login_manager desde el paquete app
from . import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    # Almacena la llave pública como texto PEM. Se usará para verificar la firma del voto.
    public_key_pem = db.Column(db.Text, unique=True, nullable=True) 
    # Rol: 'user' o 'admin'
    role = db.Column(db.String(10), nullable=False, default='user')

    def set_password(self, password):
        """Hashea la contraseña para guardarla de forma segura."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Verifica la contraseña hasheada."""
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        """Verifica si el usuario es administrador."""
        return self.role == 'admin'

    def __repr__(self):
        return f'<User {self.username}>'

# Loader para Flask-Login
from . import login_manager # Importar login_manager

class Survey(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    # Relación con las opciones
    options = db.relationship('Option', backref='survey', lazy=True)
    # Relación con los votos
    votes = db.relationship('Vote', backref='survey', lazy=True)
    
    def __repr__(self):
        return f'<Survey {self.title}>'

class Option(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    survey_id = db.Column(db.Integer, db.ForeignKey('survey.id'), nullable=False)
    text = db.Column(db.String(255), nullable=False)
    # No se guarda un contador aquí para forzar el conteo basado en votos únicos y seguros.
    
    def __repr__(self):
        return f'<Option {self.text}>'

class Vote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    survey_id = db.Column(db.Integer, db.ForeignKey('survey.id'), nullable=False)
    option_id = db.Column(db.Integer, db.ForeignKey('option.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False) # Para asegurar 1 voto/usuario
    
    # Datos de Seguridad:
    vote_data_hash = db.Column(db.String(128), nullable=False) # Hash del voto antes de cegar
    signature = db.Column(db.LargeBinary, nullable=False) # La firma digital de ese hash
    # Datos de Firma Ciega:
    blind_factor = db.Column(db.Text, nullable=False) # Factor de cegado (r)
    final_anonymous_signature = db.Column(db.LargeBinary, nullable=True) # Firma descegada (S)

    # El servidor ya no necesita guardar la firma antes de descegar. 
    # Usaremos el campo signature original para el hash del voto ciego (m_blind) durante el proceso.

    # Añadiremos un campo para verificar que el usuario no haya votado antes de la firma.
    has_signed_blind_vote = db.Column(db.Boolean, default=False)

    
    # Relaciones
    voter = db.relationship('User', backref='votes', lazy=True)
    
    def __repr__(self):
        return f'<Vote for {self.option_id} in {self.survey_id}>'
    
    

@login_manager.user_loader
def load_user(user_id):
    """Callback para recargar el objeto User desde el ID de sesión."""
    return db.session.get(User, int(user_id))