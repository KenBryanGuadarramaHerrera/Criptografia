from cryptography.hazmat.primitives.asymmetric import rsa as rsa_crypto, padding # Usamos rsa_crypto para la generación de llaves
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import utils
from cryptography.hazmat.primitives import hashes
import hashlib
import rsa # Librería 'rsa' para las operaciones de Firma Ciega (Blind Signature)

# --- Funciones de Generación y Serialización ---

def generate_rsa_key_pair(key_size=2048):
    """Genera un par de llaves RSA (Privada y Pública) usando cryptography (rsa_crypto)."""
    # 🛑 Usamos el alias rsa_crypto
    private_key = rsa_crypto.generate_private_key(
        public_exponent=65537,
        key_size=key_size,
    )
    return private_key

def serialize_private_key(private_key):
    """Serializa la llave privada al formato PEM."""
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    return pem

def serialize_public_key(private_key):
    """Serializa la llave pública de la llave privada al formato PEM."""
    public_key = private_key.public_key()
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return pem

# --- Funciones de Hashing y Firma Simple ---

def hash_vote_data(data: str) -> str:
    """Genera un hash de los datos del voto usando SHAKE128."""
    h = hashlib.shake_128(data.encode('utf-8'))
    return h.hexdigest(32)

def sign_hash(private_pem: bytes, hashed_data: str) -> bytes:
    """Firma un hash de datos usando la clave privada."""
    private_key = serialization.load_pem_private_key(
        private_pem,
        password=None
    )
    signature = private_key.sign(
        hashed_data.encode('utf-8'),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return signature

def verify_signature(public_pem: str, hashed_data: str, signature: bytes) -> bool:
    """Verifica una firma digital usando la clave pública (con corrección PEM)."""
    try:
        # Corrección automática de cabeceras PEM (para llave pública)
        clean_pem = public_pem.strip()
        if not clean_pem.startswith('-----BEGIN PUBLIC KEY-----'):
            clean_pem = ("-----BEGIN PUBLIC KEY-----\n" + clean_pem.replace('\n', '').replace('\r', '') + "\n-----END PUBLIC KEY-----")

        public_key = serialization.load_pem_public_key(
            clean_pem.encode('utf-8')
        )
        
        public_key.verify(
            signature,
            hashed_data.encode('utf-8'),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True
    except Exception as e:
        print(f"Error de verificación: {e}") 
        return False
    
# --- Funciones de Firma Ciega (Blind Signature) ---

def load_authority_public_key():
    """Carga la clave pública del servidor para cegado/descegado."""
    try:
        with open('authority_public.pem', 'rb') as f:
            return f.read().decode('utf-8')
    except FileNotFoundError:
        print("ERROR: authority_public.pem no encontrado. ¡Genere las claves de autoridad!")
        return None

def load_authority_private_key():
    """Carga la clave privada del servidor para la firma real del voto."""
    try:
        with open('authority_private.pem', 'rb') as f:
            return f.read().decode('utf-8')
    except FileNotFoundError:
        print("ERROR: authority_private.pem no encontrado. ¡Genere las claves de autoridad!")
        return None

def blind_hash(public_pem: str, hashed_data: str) -> tuple[bytes, int]:
    """Ciega el hash del voto con la llave pública de la autoridad."""
    public_key_rsa = rsa.PublicKey.load_pkcs1_pem(public_pem.encode('utf-8'))
    hash_int = int.from_bytes(hashed_data.encode('utf-8'), 'big')
    
    blinding_factor = rsa.randnum.read_random_int(public_key_rsa.n) 
    
    # Cegar: m_blind = m * (r^e) mod n
    blinded_hash = (hash_int * pow(blinding_factor, public_key_rsa.e, public_key_rsa.n)) % public_key_rsa.n
    
    blinded_hash_bytes = blinded_hash.to_bytes((blinded_hash.bit_length() + 7) // 8, 'big')
    
    return blinded_hash_bytes, blinding_factor

def sign_blinded_hash(private_pem: str, blinded_hash_bytes: bytes) -> bytes:
    """El servidor (autoridad) firma el hash cegado."""
    private_key_rsa = rsa.PrivateKey.load_pkcs1_pem(private_pem.encode('utf-8'))
    
    blinded_hash_int = int.from_bytes(blinded_hash_bytes, 'big')
    
    # Firmar: s_blind = (m_blind)^d mod n
    signed_blinded_hash_int = pow(blinded_hash_int, private_key_rsa.d, private_key_rsa.n)
    
    signature_bytes = signed_blinded_hash_int.to_bytes((private_key_rsa.n.bit_length() + 7) // 8, 'big')
    
    return signature_bytes

def unblind_signature(signed_blinded_hash_bytes: bytes, blinding_factor: int, public_pem: str) -> bytes:
    """El usuario descega la firma del servidor."""
    public_key_rsa = rsa.PublicKey.load_pkcs1_pem(public_pem.encode('utf-8'))
    signed_blinded_hash_int = int.from_bytes(signed_blinded_hash_bytes, 'big')
    
    blinding_factor_inv = rsa.common.inverse(blinding_factor, public_key_rsa.n)
    
    # Descegar: s = s_blind * (r^-1) mod n
    unblinded_signature_int = (signed_blinded_hash_int * blinding_factor_inv) % public_key_rsa.n
    
    signature_bytes = unblinded_signature_int.to_bytes((public_key_rsa.n.bit_length() + 7) // 8, 'big')
    
    return signature_bytes

def verify_anonymous_signature(public_pem_auth: str, hashed_data: str, signature_bytes: bytes) -> bool:
    """Verifica la firma anónima (descegada) usando la clave pública de la Autoridad."""
    try:
        public_key_rsa = rsa.PublicKey.load_pkcs1_pem(public_pem_auth.encode('utf-8'))
        
        signature_int = int.from_bytes(signature_bytes, 'big')
        
        # Descifrar la firma (debería darnos el hash original)
        decrypted_hash_int = pow(signature_int, public_key_rsa.e, public_key_rsa.n)
        
        decrypted_hash_bytes = decrypted_hash_int.to_bytes((decrypted_hash_int.bit_length() + 7) // 8, 'big')
        
        # El hash original debe coincidir con el hash descifrado
        return decrypted_hash_bytes.decode('utf-8').strip('\x00') == hashed_data
        
    except Exception as e:
        print(f"Error de verificación anónima: {e}")
        return False